export default class Person {
  constructor() {
    this._name = String;
    this._height = String;
    this._mass = String;
    this._hair_color = String;
    this._skin_color = String;
    this._eye_color = String;
    this._birth_year = String;
    this._gender = String;
  }
}